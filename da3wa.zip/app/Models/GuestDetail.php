<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GuestDetail extends Model
{
    protected $table = 'guestdetails';
    protected $primaryKey = 'id';

    protected $fillable = [
        'guest_id', 'guest_name', 'job', 'phone', 'email', 'filled_status'
    ];

    public function guest()
    {
        return $this->belongsTo(Guest::class, 'guest_id', 'id');
    }
}