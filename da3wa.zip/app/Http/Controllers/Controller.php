<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use \Carbon\Carbon;
use \App\Models\{Pdflist,User};
use PDF;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function __construct()
    {
        $users          = User::get();
        // $types          = [ 'التسويق الرقمي' , 'الإنتاج المرئي', 'قبة', 'كيت', 'دَن' ];
        // $services       = [ 'عقد للشريك', 'عقد للمورّد', 'عرض سعر', 'فاتورة', 'محضر اجتماع' ];
        // $services_name  = [ 'NDA', 'اتفاقية مشروع', 'اتفاقية تمثيل', 'اتفاقية عمل', 'اتفاقية تمثيل', 'اتفاقية مصور', 'عرض سعر', 'عرض سعر مع فكرة', 'Eskelah Rate Card', 'عرض السعر مع فكرة', 'عرض سعر مفصل', 'فاتورة', 'محضر اجتماع' ];

        View()->share('users', $users);
        // View()->share('types', $types);
        // View()->share('services', $services);
        // View()->share('services_name', $services_name);
    }

}
