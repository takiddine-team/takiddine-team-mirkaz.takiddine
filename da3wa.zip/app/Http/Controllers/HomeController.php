<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Models\Pdflist;
use PhpParser\Node\Stmt\Foreach_;

use function PHPUnit\Framework\isNull;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => 'invoice_qr_code']);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        // $done = config('done');
        // return view('done',compact('done'));
        $services = config('eskelah_services');
        return view('home',compact('services'));
    }

    public function invoice_qr_code($qr){
        $invoice = Pdflist::where('qr_code',$qr)->first();
        $invoice = json_decode($invoice);
        if( empty($invoice) ){
            return response()->json( ['message'   => 'Not found'] );
        }else{
            return response()->json( [
                'message'   => 'ok',
                'service'   => $invoice->service,
                'type'      => $invoice->service_pdf,
                'data'      => $invoice->json
            ] );
        }

    }

}
