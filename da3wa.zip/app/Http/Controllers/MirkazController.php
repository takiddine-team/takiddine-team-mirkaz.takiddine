<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Guest;
use App\Models\GuestDetail;
use Illuminate\Support\Str;
use \Carbon\Carbon;
use PDF;

class MirkazController extends Controller
{

    public function __construct()
    {
        // $this->middleware('auth', ['except' => 'guest-details']);
    }


    public function invitaion(Request $request)
    {
        $validatedData = $request->validate([
            'company_name' => 'required|string|max:255',
            'number' => 'required|integer',
            'date' => 'required|date',
            'period' => 'required|string',
            'location' => 'required|string',
        ]);

        $guest = Guest::create($validatedData);

        $invitationToken = Str::uuid();

        $guest->update(['invitation_link' => $invitationToken]);

        $invitationLink = route('guest-details', ['token' => $invitationToken]);
        
        return response()->json(['invitation_link' => $invitationLink], 201);
    }

    public function show($token)
    {
        $guest = Guest::where('invitation_link', $token)->first();
    
        if (!$guest) {
            abort(404);
        }
    
        return view('invitation', compact('guest'));
    }

    public function store(Request $request)
    {
        // Validate the form data
        $validatedData = $request->validate([
            'guest_id' => 'required|integer',
            'guest_name' => 'required|string',
            'job' => 'nullable|string',
            'phone' => 'required|string',
            'email' => 'required|email',
        ]);

        $guest = Guest::find($validatedData['guest_id']);

        if (!$guest || $guest->number <= 0) {
            return redirect()->back()->with('error', 'لقد استنفذت عدد الدعوات الممنوحة لكم');
        }

        $guestDetail = GuestDetail::create([
            'guest_id' => $validatedData['guest_id'],
            'guest_name' => $validatedData['guest_name'],
            'job' => $validatedData['job'],
            'phone' => $validatedData['phone'],
            'email' => $validatedData['email'],
        ]);

        $guest->decrement('number');

        $this->invitaion_pdf( $guestDetail, 'pdf1' );

        return redirect()->back()->with('success', 'تم إرسال الدعوه بنجاح');
    }

    public function invitaion_pdf($content,$view){
        
        $name = $content->guest_name;
        view()->share('content',$content);
        $pdf_name = $name.'_'.Carbon::now()->toDateTimeString().'.pdf';

        $pdf = PDF::loadView($view)->setPaper('a4')->setOrientation('portrait')->setOption('margin-bottom', 0)->setOption('margin-top', 0)->setOption('margin-left', 0)->setOption('margin-right', 0);
            
        $pdfname = base_path('public/pdf/'.$pdf_name);
        $pdf->save( $pdfname );

        return $pdf->inline($pdf_name);
    }
    

}
