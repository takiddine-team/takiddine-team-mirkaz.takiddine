<?php



return [
    // [
    //     'image' => '/img/assets/Rectangle2.png',
    //     'logo' => '/img/assets/Groupe1.svg',
    //     'button' => '/img/assets/b_1.svg',
    //     'route' => 'vp.index',
    //     'hover_btn' => '/img/assets/b_1_hover.svg',
    //     'custom_class' => 'vp-index'
    // ],
    // [
    //     'image' => '/img/assets/Rectangle1.png',
    //     'logo' => '/img/assets/Groupe2.svg',
    //     'button' => '/img/assets/b_1.svg',
    //     'route' => 'digital.index',
    //     'hover_btn' => '/img/assets/b_1_hover.svg',
    //     'custom_class' => 'digital-index'

    // ],
    // [
    //     'image' => '/img/assets/Rectangle4.png',
    //     'logo' => '/img/assets/Groupe3.svg',
    //     'button' => '/img/assets/b_1.svg',
    //     'route' => 'kit.index',
    //     'hover_btn' => '/img/assets/b_1_hover.svg',
    //     'custom_class' => 'kit-index'

    // ],
    // [
    //     'image' => '/img/assets/Rectangle3.png',
    //     'logo' => '/img/assets/Groupe4.svg',
    //     'button' => '/img/assets/b_1.svg',
    //     'route' => 'qubbah.index',
    //     'hover_btn' => '/img/assets/b_1_hover.svg',
    //     'custom_class' => 'qubbah-index'

    // ],
    [
        'image' => '/img/assets/done-bg.png',
        'logo' => '/img/assets/dibe-link.png',
        'button' => '/img/assets/b_1.svg',
        'route' => 'done.index',
        'hover_btn' => '/img/assets/b_1_hover.svg',
        'custom_class' => 'kit-index donee'

    ]
];
