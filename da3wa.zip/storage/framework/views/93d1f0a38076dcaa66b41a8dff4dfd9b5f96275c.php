
<?php $__env->startSection('content'); ?>

    <section class="main">
        <div class="container">

            <img class="main-logo" src="/assets/img/logo.svg" alt="مركاز البلد الأمـين">

            <div class="pdf-hero-txt">
                <h4 class="name"> أ. هشام كعكي </h4>
                <h4 class="organisation"> العضو المنتدب لشركة البلد الأمين </h4>

                <h3 class="title"> مبادرة مركاز البلد الأمــــــــــــــــــــين <br> تسعــــــــــــــــــــــــد بتشريفــــــــــــــــــــــــــــــــــك </h3>
                <h5 class="sub-title"> في حضرة أصحاب المعالي والسعادة على مائدة الإفطار </h5>
            </div>

            <div class="event-info-container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="event-info">
                            <img src="/assets/img/icon-date.svg" alt="" class="icon">
                            <h6> التاريخ </h6>
                            <p> 06-03-2024 </p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="event-info">
                            <img src="/assets/img/icon-clock.svg" alt="" class="icon">
                            <h6> فترة الحدث </h6>
                            <p> لقاء الإفطار 6م - 8م </p>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="event-info">
                            <img src="/assets/img/icon-date.svg" alt="" class="icon">
                            <h6> الموقع </h6>
                            <p> اضغط هنا للوصول </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="qrcode-container">
                    <img src="/assets/img/qr-code.svg" alt="">
                </div>
            </div>

        </div>
    </section>

    <div class="container">
        <hr class="home-line">
    </div>

    <section class="about">
        <div class="container">
            <h4> عن المبادرة </h4>
            <p> <span> تمثّل المبادرة جزءًا أساسيًا من استراتيجية تعزيز الشراكة </span> وتوطيد العلاقة مع أصحاب العلاقة في العاصمة المقدسة، نُقدم من خلالها منصة حوارية اتصالية فعالة تجمع، بين أصحاب المصلحة من أصحاب المعالي والمسؤولين ورجال الأعمال، بهدف تعــــــــــزيز
                تبادل الآراء والخبرات، وتقديم بيئة تشجيعية للتعاون وفتح باب الشراكات والفرص في مجال الاستثمار والتنمية والتطوير لرفع مستوى جودة الحياة في المنطقة، وتعزيز التواصل الفعّال. </p>
            <a href="#" class="objectives-link"> انقر هنا للتعرّف أكثر </a>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\da3wa\resources\views/pdf1.blade.php ENDPATH**/ ?>