<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{HomeController, PdfgeneratorController, HistoryController, ClientController, doneController};
use App\Http\Controllers\UserController;
use App\Http\Controllers\MirkazController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


////Auth
Auth::routes();
////Home
Route::get('/', [HomeController::class, 'index'])->name('home');
////QrCode
Route::get('/qr/{qr}', [HomeController::class, 'invoice_qr_code'])->name('qr_code');

////History
// Route::group(['prefix' => 'history', 'as' => 'history.', 'middleware' => ['auth:web']], function () {

//     Route::get('/', [HistoryController::class, 'index'])->name('index');

//     Route::get('/create', [HistoryController::class, 'create'])->name('create');

//     Route::post('/store', [HistoryController::class, 'store'])->name('store');

//     Route::get('/edit/{id}', [HistoryController::class, 'edite'])->name('edit');

//     Route::post('/update/{id}', [HistoryController::class, 'update'])->name('update');

//     Route::delete('/delete/{id}', [HistoryController::class, 'delete'])->name('delete');

//     Route::get('/duplicate/{id}', [HistoryController::class, 'duplicate'])->name('duplicate');

//     Route::get('/search', [HistoryController::class, 'search'])->name('search');
// });

//users
// Route::group(['prefix' => 'users', 'as' => 'users.', 'middleware' => ['auth:web']], function () {

//     Route::get('/', [UserController::class, 'index'])->name('index');

//     Route::get('/create', [UserController::class, 'create'])->name('create');

//     Route::post('/store', [UserController::class, 'store'])->name('store');

//     Route::get('/edit/{id}', [UserController::class, 'edite'])->name('edit');

//     Route::post('/update/{id}', [UserController::class, 'update'])->name('update');

//     Route::delete('/delete/{id}', [UserController::class, 'delete'])->name('delete');
// });

//Clients
// Route::group(['prefix' => 'clients', 'as' => 'clients.', 'middleware' => ['auth:web']], function () {

//     Route::get('/', [ClientController::class, 'index'])->name('index');

//     Route::get('/create', [ClientController::class, 'create'])->name('create');

//     Route::post('/store', [ClientController::class, 'store'])->name('store');

//     Route::get('/edit/{id}', [ClientController::class, 'edite'])->name('edit');

//     Route::post('/update/{id}', [ClientController::class, 'update'])->name('update');

//     Route::delete('/delete/{id}', [ClientController::class, 'delete'])->name('delete');
// });

Route::get('/clear-cache', function() {
    
    Artisan::call('view:clear');
    Artisan::call('cache:clear');
    Artisan::call('route:clear');
    Artisan::call('config:clear');
    Artisan::call('optimize:clear');
    
    return 'Cache Cleared Successfully';
});



// use Illuminate\Support\Facades\DB;
// Route::get('/doc_nbr', function() {
//     $pdf_li = \App\Models\Pdflist::get();
//     $doc_nb = [];

//     foreach ($pdf_li as $key => $pdf) {
//         $js = json_decode( $pdf->json,true );

//         $pp = \App\Models\Pdflist::where( 'id', $pdf->id )->first();
//         $pp->doc_nbr = $js['contract_id'] ?? $js['invoice-number'] ?? $js['offernumber'] ?? $js['invoice_number'] ?? 'N-A';
//         $pp->save();
//     }

//     dd('ok');
// });

Route::post('/invitaion', [MirkazController::class, 'invitaion'])->name('invitaion')->middleware(['auth:web']);
Route::get('/invitaion/{token}', [MirkazController::class, 'show'])->name('guest-details');
Route::post('/invitaion/store', [MirkazController::class, 'store'])->name('guest-details-store');
